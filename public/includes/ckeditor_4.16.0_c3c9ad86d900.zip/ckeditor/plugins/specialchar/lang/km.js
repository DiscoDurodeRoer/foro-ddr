﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'km', {
	options: 'ជម្រើស​តួ​អក្សរ​ពិសេស',
	title: 'រើស​តួអក្សរ​ពិសេស',
	toolbar: 'បន្ថែមអក្សរពិសេស'
} );
