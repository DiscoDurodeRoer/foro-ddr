﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'sr-latn', {
	label: 'Stil',
	panelTitle: 'Stilovi formatiranja',
	panelTitle1: 'Blok stilovi',
	panelTitle2: 'Inline stilovi',
	panelTitle3: 'Stilovi objekta'
} );
