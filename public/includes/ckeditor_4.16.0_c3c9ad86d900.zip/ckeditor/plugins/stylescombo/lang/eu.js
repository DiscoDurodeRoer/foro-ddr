﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'eu', {
	label: 'Estiloak',
	panelTitle: 'Formatu estiloak',
	panelTitle1: 'Bloke estiloak',
	panelTitle2: 'Lineako estiloak',
	panelTitle3: 'Objektu estiloak'
} );
