﻿/*
Copyright (c) 2003-2021, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'sr-latn', {
	confirmCleanup: 'Kopirani tekst je iz Word-a. Želite ga očistiti? ',
	error: 'Zbog interne greške tekst nije očišćen.',
	title: 'Zalepi iz Worda',
	toolbar: 'Zalepi iz Worda'
} );
